.. cmake-module:: ../../rapids-cmake/cmake/make_global.cmake
