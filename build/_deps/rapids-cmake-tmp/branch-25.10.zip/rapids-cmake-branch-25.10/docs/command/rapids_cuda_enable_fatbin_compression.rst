.. cmake-module:: ../../rapids-cmake/cuda/enable_fatbin_compression.cmake
