.. cmake-module:: ../../rapids-cmake/test/install_relocatable.cmake
