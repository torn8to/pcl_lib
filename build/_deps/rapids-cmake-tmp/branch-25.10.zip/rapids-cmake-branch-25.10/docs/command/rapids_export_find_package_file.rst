.. cmake-module:: ../../rapids-cmake/export/find_package_file.cmake
