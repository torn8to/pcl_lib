.. cmake-module:: ../../rapids-cmake/cpm/bs_thread_pool.cmake
